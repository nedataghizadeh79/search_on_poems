#!/usr/bin/env python
# coding: utf-8

# <h2 dir="rtl">
# ندا تقی زاده سراجه
#     <br>
# 
#     98170743
#     
#     موضوع: متون شعرای مختلف .
# </h2>

# <h3 dir="rtl">
#     
# در این تمرین قصد داریم داده با کمک کتابخانه های beautifulSoup , request  استفاده نماییم و داده هایمان را از سایت مد نظر (گنجور) کراول کنیم.                    
#  
# همچنین توضیحات نحوه ی استفاده از این کتابخانه و دستورات بیشتر آن در لینک روبه رو قابل مشاهده است.
#     [check this Web Site](https://www.crummy.com/software/BeautifulSoup/bs4/doc/)
# </h3>

# In[36]:


import  requests
from bs4 import BeautifulSoup


# <h4 dir="rtl">
# در تمرین فردی خود قصد کراول کردن دیتا از سایت گنجور را دارم که در ابتدا آدرس سایت مربوطه را درون متغیری ریخته و همچنین  آرایه ای پیرامون نگه داری تمامی لینک های صفحه ی اول سایت نگه میداریم.
# </h4>

# In[3]:


base_url="https://ganjoor.net"

all_links_list=[]


# <h4 dir="rtl">
# همچنین از سه دسته ی گوناگون شاعر انتخاب کرده و لیست های مربوطه را برای ذخیره سازی لینک های سه دسته ی                 شاعران مرد قدیمی و شاعران زن قدیمی و شاعران امروزی طبقه بندی مینماییم و همچنین لیست دیگری طراحی میکنیم که نام تمامی این افراد را نگه داری کند.
# </h4>

# In[4]:


women_poets_list=[]
men_poets_list=[]
contemporary_poets_list=[]
all_names_list=[]


# <h4 dir="rtl">
# در تابع زیر به سایت مد نظر درخواست فرستاده و تمامی لینک های موجود که با تگ  a  آغاز میشوند را باز میگرداند و درون لیست مربوطه مان نگه داری میکنیم.
# </h4>

# In[5]:


def send_request( address , class_name , list_name , base_url ):
  request_first_page= requests.get(address)
  soup_first_page = BeautifulSoup(request_first_page.text, "html.parser")
  poets_first_page = soup_first_page.select(class_name)
  for i in poets_first_page:
    list_name.append(base_url + str(i.a['href']))


# <h4 dir="rtl">
# با توجه به ساختار سایت گنجور، تمامی لینک های درون صفحه ی اول سایت جمع آوری شده و حالا باید دنبال لینکهای مد نظرمان بر اساس شاعرانی که میخواهیم باشند، پس به تابع زیر اسم شاعران مربوطه را میدهیم که لینک آدرس هر صفحه ی شاعر را درون لیست های از پیش تعریف شده مان ذخیره سازد.
# </h4>

# In[6]:


def select_poets(links_list, name1, name2, name3, poestList):
  for i in links_list:

    if i.__contains__(name1) or i.__contains__(name2) or i.__contains__(name3):
      if i not in poestList: #Avoid adding duplicates
        poestList.append(i)


# <h4 dir="rtl">
# تابع زیر هم برای این است که هنگامی که داده هایمان را کراول کردیم درون فایل بنویسیم.
# </h4>

# In[7]:


def write_in_file( filename , mesrae_list ):
  with open(filename , 'w' , encoding="UTF-8") as f:
    for i in mesrae_list:
      f.write("%s\n" % i)


# <h4 dir="rtl">
# در خط زیر تابع از پیش تعریف شده را صدا میزنیم و با توجه به کلاس مربوطه، داده ی مورد نظرمان را از این صفحه جمع آوری میکنیم.
# </h4>

# In[8]:


send_request("https://ganjoor.net"  ,  ".poet"  , all_links_list , base_url)


# <h4 dir="rtl">
# در سلول زیر هم تابع از پیش تعریف شده ی مربوطه را فرا میخوانیم و شاعرانی که مدنظر داریم را میابیم و لینک هایشان را درون لیست های از پیش ساخته شده میریزیم.
# </h4>

# In[9]:


select_poets(all_links_list, "hafez", "ferdousi", "vahshi", men_poets_list)
select_poets(all_links_list, "mahsati" , "jahan", "afsar", women_poets_list)
select_poets(all_links_list, "iraj" ,"parvin", "shahriar", contemporary_poets_list)


# <h4 dir="rtl">
# در سایت گنجور برای دیدن اشعار مربوطه باید از دو پارت عبور کرد و برای برخی دیگر از شعرا با عبور کردن از یک صفحه میتوان به اشعار مربوطه دست یافت برای روشن تر کردن مطلب به دو مثال زیر دقت فرمایید:
#     
#     برای مثال اگر به دنبال اشعار فردوسی میگردین، ابتدا باید وارد صفحه ی اولیه سایت گنجور شوید و پس از کلیک بر روی نام فردوسی به صفحه ای منتقل میشوید که باید از بین کتبش یکی را برگزینید حالا پس از انتخاب نام کتاب، به صفحه ی دیگری منتقل میشوید که نوع و دسته بندی شعر مربوطه تان را انتخاب کنید که این فرآیند در دو پارت انجام میشود.
#     و همچنین اگر شما به دنبال اشعار حافط باشید و در صفحه ی اولیه و اصلی سایت گنجور روی اسم این شاعر کلیک کنید به صفحه ای میروید که اشعار وی را دسته بندی کرده (مثلا غزلیات، قطعات، رباعیات و....) سپس با انتخاب نوع شعر مورد نر برایتان اشعار مربوزه نشان داده میشود این مثالی از تک پارتی بود که در تابع بعدی کد آن درج شده است (به عبارتی در کد زیر ما مجبوریم یک صفحه را بیشتر بگردیم تا به داده ی مورد نظر دست یابیم.)  
# </h4>

# In[10]:


def get_poems_in_two_part_pages(list_of_poet , index , name1 , name2  , all_names_list):
  hafez_link = str(list_of_poet[index])+"/"
  poet_href_list = []
  send_request( hafez_link ,  ".part-title-block" , poet_href_list , base_url)


  kind_of_poem_link= ""
  for i in poet_href_list:
    if i.__contains__(name1):
      kind_of_poem_link = i +"/"


  all_kinds_links_list = []
  send_request(kind_of_poem_link  , ".part-title-block" , all_kinds_links_list , base_url )


  part2=""
  for i in all_kinds_links_list:
    if i.__contains__(name2):
      part2 = i +"/"


  all_kinds_links_list2 = []
  send_request(part2  , ".poem-excerpt" , all_kinds_links_list2 , base_url )


  mesraee_list=[]

  for i in all_kinds_links_list2:
    request_mesraee = requests.get( str(i) )
    soup_mesraee_page = BeautifulSoup(request_mesraee.text, "html.parser")
    mesraee = [div.get_text()  for div in soup_mesraee_page.select('div[class^="m"]') ][0: -1]
    mesraee_list += mesraee

  file_name=  str(list_of_poet[index]).split("/")[3]+"_"+name2+".txt"
  all_names_list.append(  str(file_name))
  write_in_file( file_name , mesraee_list )


# <h4 dir="rtl">
# این تابع هم مشابه تابع قبلی است که مثالی هم برای این مورد ذکر شد.
# </h4>

# In[11]:


def get_single_page_poems(list_of_poet, name1, index , all_names_list):
  hafez_link = str(list_of_poet[index]) + "/"
  poet_href_list = []
  send_request( hafez_link ,  ".part-title-block" , poet_href_list , base_url)


  kindof_poet_link= ""
  for i in poet_href_list:
    if i.__contains__(name1):
      kindof_poet_link = i +"/"


  all_poet_links_list = []
  send_request(kindof_poet_link  , ".poem-excerpt" , all_poet_links_list , base_url )

  mesraee_list=[]

  for i in all_poet_links_list:
    request_mesraee = requests.get( str(i) )
    soup_mesraee_page = BeautifulSoup(request_mesraee.text, "html.parser")
    mesraee = [div.get_text()  for div in soup_mesraee_page.select('div[class^="m"]') ][0: -1]
    mesraee_list += mesraee

  file_name =  str(list_of_poet[index]).split("/")[3] + "_" + name1 + ".txt"
  all_names_list.append(  str(file_name) )
  write_in_file( file_name , mesraee_list )


# <h4 dir="rtl">
# حالا بر اساس دو پارتی یا تک پارتی بودن شاعران آنها را در توابع مربوط به خود صدا میزنیم
# همچنین اگر به ساختار سایت آشنایی نداشته باشید و در نحوه ی صدا زدن شاعر شک داشته باشید با توجه به کتب شاعر و سبک های شعری وی میتوان فهمید که وی را در چه تابعی گنجاند و کال کرد
# </h4>

# In[12]:


get_single_page_poems(men_poets_list, "ghazal", 0 , all_names_list)
get_poems_in_two_part_pages(men_poets_list , 1 , "shahname" , "sohrab" , all_names_list )
get_poems_in_two_part_pages(men_poets_list , 2 , "divanv" , "ghazalv" , all_names_list )

get_single_page_poems(contemporary_poets_list , "ghaside", 0 , all_names_list)
get_poems_in_two_part_pages(contemporary_poets_list , 1 , "divanp" , "ghasidep" , all_names_list )
get_single_page_poems(contemporary_poets_list , "gozidegh", 2 , all_names_list)

get_single_page_poems(women_poets_list , "robmah", 0 , all_names_list )
get_poems_in_two_part_pages(women_poets_list ,1 , "divan" , "ghaside" , all_names_list)
get_single_page_poems(women_poets_list , "kooroshname", 2 , all_names_list )


# <h4 dir="rtl">
# لینک های جمع آوری شده را در لیست مربوطه پرینت میکنیم.
# </h4>

# In[13]:


print(all_names_list)


# <h4 dir="rtl">
# حال با توجه به دیتاهای جمع آوری شده و کتاب خانه های مربوطه مصراع ها را خوانده و درون دیکشنری ای ذخیره میکنیم که کلیدش نام شاعر مربوزه (نام فایل )است و ولیوهای آن مصراع ها است و همچنین سپس آنها را نرمال سازی کرده و برای مثال مموارد اضافی از قبیل اعراب و ... را پاک سازی میکنیم.
# </h4>

# In[14]:


import hazm
import tqdm
from hazm import *
import random
import codecs

mesra_collection_dict={}

normalizer = Normalizer()

mesra_normalized = {}


for i in all_names_list:
    mesra_collection_dict[i] = [x.strip().split() for x in
                                tqdm.tqdm(codecs.open( i , 'rU', 'utf-8').readlines())]

    mesra_normalized[i] = [[normalizer.normalize(y) for y in x] for x in tqdm.tqdm(mesra_collection_dict[i])]


# <h4 dir="rtl">
# حالا موارد ساخته شده را پرینت میکنیم.
# </h4>

# In[15]:


print(mesra_collection_dict)


# In[16]:


print(mesra_normalized)


# <h4 dir="rtl">
# حال در ادامه قصد داریم فرکانس کل کلمات را بگیریم که کلا هر کلمه چند بار تکرار شده که در دیکشنری فرکانس ذخیره میشوند(کلمات کلیدمان هستند و ولیو شان تعداد تکرارشان است.)
# </h4>

# In[17]:


frekans={}

def find_counts_of_each_word_for_all_poets(frekans):
    for key , value in mesra_normalized.items():
        for mesrae in value:
            for i in mesrae:
                if i not in frekans.keys():
                    frekans[i]=1
                else:
                    frekans[i]= (frekans[i]+1)


# <h4 dir="rtl">
# حال تابع مربوطه را کال کرده و سپس دیکشنری فرکانس را نشان میدهیم.
# </h4>

# In[18]:


find_counts_of_each_word_for_all_poets(frekans)
print(frekans)
# for all


# <h4 dir="rtl">
# حال در کد زیر میخواهیم ببینیم که چه کلمه ای بیشتر تکرار شده و آن را نمایش میدهیم.
# </h4>

# In[19]:


most_repitation= max(frekans.items(), key=lambda t: t[::-7])
print(most_repitation)


# <h4 dir="rtl">
# در کد زیر کلمات را از کمترین بار تکرار تا بیشترین تکرار نمایش میدهیم.
# </h4>

# In[20]:


sorted_words_maxUses_to_smaleestUses_list = sorted(frekans, key=frekans.get, reverse=False)
print(sorted_words_maxUses_to_smaleestUses_list)


# <h4 dir="rtl">
# حالا صدتا کلمه ای که بیشترین بار تکرار شده اند را پیدا میکنیم تا در تمامی  داده های کراول شده مان آنها را بررسی نماییم و در دیکشنری هایی که در ادامه تعریف کردیم، ذخیره نماییم.
# </h4>

# In[21]:


num=100
most100_list=[]

for i in reversed(sorted_words_maxUses_to_smaleestUses_list):
    if num ==0:
        break
    else:
        most100_list.append(i)
        num-=1
        
print(most100_list)


# In[22]:


hafez_dict = {}
ferdousi_dict = {}
vahshi_dict = {}
mahsati_dict = {}
jahan_dict = {}
afsar_dict = {}
iraj_dict = {}
parvin_dict = {}
shahriar_dict = {}

dicts_names_list=[hafez_dict,ferdousi_dict,vahshi_dict,mahsati_dict,jahan_dict,afsar_dict,iraj_dict,parvin_dict,shahriar_dict]


iraj_list_words=[]
ferdousi_list_words=[]
hafez_list_words=[]
jahan_list_words=[]
mahsati_list_words=[]
parvin_list_words=[]
shahriar_list_words=[]
vahshi_list_words=[]
afsar_list_words=[]


# <h4 dir="rtl">
# در تابع زیر 100 کلمه ی پر تکرار را در داده هایمان بررسی میکنیم و تعداد تکرر هر یک از کلمات را در هر فایل به دست میاوریم.
# </h4>

# In[23]:


def fill_dicts(contents , yourlist_word , most100_list , your_dict  ):
    for j in contents:
        yourlist_word += (j.replace("\n", "").split(" "))

    for most_word in most100_list:
        for afsar_word in yourlist_word:
            if most_word == afsar_word:
                if most_word not in your_dict.keys():
                    your_dict[most_word] = 1
                else:
                    your_dict[most_word] = your_dict[most_word] + 1


# <h4 dir="rtl">
# باتوجه به تابع قبل و داده هایمان دیکشنری های از پیش تعریف شده را مطابق انتظارمان پر میکنیم.
# </h4>

# In[24]:


contents=''
for i in all_names_list:
    with open(i , 'r' , encoding="UTF-8" ) as f:
        contents = f.readlines()

        if i.__contains__("hafez"):
            fill_dicts(contents , hafez_list_words , most100_list , hafez_dict  )
            
        if i.__contains__("ferdousi"):
            fill_dicts(contents , ferdousi_list_words , most100_list , ferdousi_dict  )
        
        if i.__contains__("vahshi"):
            fill_dicts(contents , vahshi_list_words , most100_list , vahshi_dict  )

            
        if i.__contains__("mahsati"):
            fill_dicts(contents , mahsati_list_words , most100_list , mahsati_dict  )

        if i.__contains__("jahan"):
            fill_dicts(contents , jahan_list_words , most100_list , jahan_dict  )

        if i.__contains__("afsar"):
            fill_dicts(contents , afsar_list_words , most100_list , afsar_dict  )


        if i.__contains__("iraj"):
            fill_dicts(contents, iraj_list_words, most100_list, iraj_dict)

        if i.__contains__("parvin"):
            fill_dicts(contents , parvin_list_words , most100_list , parvin_dict  )

        if i.__contains__("shahriar"):
            fill_dicts(contents , shahriar_list_words , most100_list , shahriar_dict  )

        


# <h4 dir="rtl">
# حال نتایج مان را نشان میدهیم که در هر یک از اشعار شاعر مربوطه آن 100 کلمه ی پرتکرار به صورت اختصاصی در داک شاعر مربوطه چندبار آمده.
#     لازم به ذکر است که میتوانستیم تمامی دیکشنری ها را درون لیست بریزیم و نتایج مان را درون لوپ و مختصرتر نشان دهیم اما برای اینکه جداجدا و بهتر نشان داده شود به صورت جدا برای هر یک از شاعران نتایج را جدا نشان میدهیم.
# </h4>

# In[25]:


print(hafez_dict)


# In[26]:


print(ferdousi_dict)


# In[27]:


print(vahshi_dict)


# In[28]:


print(mahsati_dict)


# In[29]:


print(jahan_dict)


# In[30]:


print(afsar_dict)


# In[31]:


print(iraj_dict)


# In[32]:


print(parvin_dict)


# In[33]:


print(shahriar_dict)


# In[34]:


for i in dicts_names_list:
    print (i)


# <h4 dir="rtl">
# حالا در تابع زیر میانگین استفاده ی کلمات در کل متون مون محاسبه می شود و شما میتوانید با دادن کلمه ی مربوطه تکرر آن را بیابید.
# </h4>

# In[74]:


res=0
def calc_avg_used_word_in_allFiles(res , word):
    try:
        for i  in dicts_names_list:
            res +=(i.get(word))
        res= res/len(dicts_names_list)
        print("The average value of %s is equal to = "%word , end="")
        print(res)
        print()
    except:
        print("we dont have %s "%word)
        print()
        


# <h4 dir="rtl">
# حالا برای چند کلمه تابع بالا را ران میکنیم.
# </h4>

# In[75]:


word1="و"
calc_avg_used_word_in_allFiles(res , word1)

word2="من"
calc_avg_used_word_in_allFiles(res , word2)

word3="غم"
calc_avg_used_word_in_allFiles(res , word3)

word4="ندااااااااااااااااااا"
calc_avg_used_word_in_allFiles(res , word4)


# <h4 dir="rtl">
# حالا قصد داریم برخی از کلمات حماسی را از سایت ویکی پدیا کراول کنیم و درصد تکرار آنها را در اشعار شاعران مان بررسی کنیم  و لازم به ذکر است که در هنگام کراول کردن تعداد زادی کلمات انگلیسی و چندتا ایتالیایی نیز در خروجی مان دیده میشود که با کمک کتابخانه ی nltk  توانستم کلمات انگلیسی را شناسایی و حذف نمایم اما برای حذف کلمات ایتالیایی که فقط چند مورد بودند انها را درون شرط هندل میکنم. 
# </h4>

# In[86]:


import nltk
nltk.download('words')
words = set(nltk.corpus.words.words())


# <h4 dir="rtl">
# میخواهیم در سلول بعدی کلمات حماسی مربوطه را از سایت زیر کراول نماییم.
# 
#     
# [check this Web Site](https://fa.wikipedia.org/wiki/%D9%81%D9%87%D8%B1%D8%B3%D8%AA_%D9%88%D8%A7%DA%98%DA%AF%D8%A7%D9%86_%D9%86%D8%B8%D8%A7%D9%85%DB%8C_%DA%A9%D8%A7%D8%B1%D8%A8%D8%B1%D8%AF%DB%8C)
#     
#     
#     
#     
# لازم به ذکر است که درون متغیر select_class  ما کلماتی را که مال کلاس مربوطه است را اخذ کردیم اما بخاطر وجود ناخالصی نیاز به پاکسازی دارند.
#     
# </h4>

# In[87]:


address_of_site_for_hemasi_words="https://fa.wikipedia.org/wiki/%D9%81%D9%87%D8%B1%D8%B3%D8%AA_%D9%88%D8%A7%DA%98%DA%AF%D8%A7%D9%86_%D9%86%D8%B8%D8%A7%D9%85%DB%8C_%DA%A9%D8%A7%D8%B1%D8%A8%D8%B1%D8%AF%DB%8C"
request_= requests.get(address_of_site_for_hemasi_words)
soup_ = BeautifulSoup(request_.text, "html.parser")
select_class = soup_.select(".new")


# <h4 dir="rtl">
# برای حذف موارد غیر از کلمات مورد نیاز با توجه به دستوری که درون متغیر  other_than_EnglishWords ریختیم قصد داریم که کلمات انگلیسی را دور بریزیم.
# </h4>

# In[91]:


crowled_hamasi_worsd_list=[]

for i in select_class:
    print(i.string)
    other_than_EnglishWords = " ".join(w for w in nltk.wordpunct_tokenize(i.string) if not w.lower() in words or not w.isalpha())
    crowled_hamasi_worsd_list.append(other_than_EnglishWords)


# <h4 dir="rtl">
# در تابع زیر چند کلمه ایتالیایی که در کلمات است را حذف کرده ئ حالا درون لیست just_hemasi_words_list ما کلمات حماسی فارسی را بدون ناخالصی داریم.
#     
# همچنین کلمات اضافی را نیز حذف میکنیم.
#     
# </h4>

# In[143]:


just_hemasi_words_list=[]
chore_words=["reduit" , "ESCALADE" , "italienne" , "Camouflet" , "Scuttling" , "VEDETTE" , "Chevaux" , 'Circumvallation' ,"Contravallation" , "Salients" ,"Chevaux د frize" , '\u200c' ]

def clear_unnecessary_data(just_hemasi_words_list  , crowled_hamasi_worsd_list ,chore_words ):
    splited_hemasi_persian_words=[]
    for i in crowled_hamasi_worsd_list:
        splited_hemasi_persian_words += (i.split(" "))
    
    for i in splited_hemasi_persian_words:
        if (i not in chore_words):
            if i not in just_hemasi_words_list:
                just_hemasi_words_list.append(i)
                


# In[145]:


clear_unnecessary_data(just_hemasi_words_list  , crowled_hamasi_worsd_list ,chore_words )

for i in just_hemasi_words_set:
    print(i)


# <h4 dir="rtl">
# حالا در ادامه میخواهیم با توجه به لیست کلمات حماسی کراول شده، تعداد آنها را در اشعار شاعران مان مقایسه کنیم. لازم به ذکر است که این ایده میتواند به شناسایی سبک شعری نیز کمک کند. برای این کار ابتدا تابعی را برای خواندن اشعار شاعرمان میسازیم و سپس صدا میکنیم.
# </h4>

# In[129]:


def read_from_file( fileName , list_name):
    with open(fileName , 'r', encoding="UTF-8") as f:
        list_name += f.readlines()
        


# <h4 dir="rtl">
# حالا در ادامه تابع بالا را صدا میکنیم تا اشعار شاعران مان را با سبک های مختلف دریابیم.
# </h4>

# In[183]:


hafez_mesrae_list=[]
read_from_file("hafez_ghazal.txt", hafez_mesrae_list)

ferdousi_mesrae_list=[]
read_from_file("ferdousi_sohrab.txt", ferdousi_mesrae_list)

vahshi_mesrae_list=[]
read_from_file("vahshi_ghazalv.txt", vahshi_mesrae_list)

mahsati_mesrae_list=[]
read_from_file("mahsati_robmah.txt", mahsati_mesrae_list)

jahan_mesrae_list=[]
read_from_file("jahan_ghaside.txt", jahan_mesrae_list)

afsar_mesrae_list=[]
read_from_file("afsar_kooroshname.txt", afsar_mesrae_list)

iraj_mesrae_list=[]
read_from_file("iraj_ghaside.txt", iraj_mesrae_list)

parvin_mesrae_list=[]
read_from_file("parvin_ghasidep.txt", parvin_mesrae_list)

shahriar_mesrae_list=[]
read_from_file("shahriar_gozidegh.txt", shahriar_mesrae_list)


# <h4 dir="rtl">
# همچنین برای اینکه تعداد کلمات حماسی دیده شده (با توجه به لیست کراول کرده مان) که در نهایت ببینیم چندتا هستند، برای هر یک از شعرا متغیرهایی میسازیم.
# </h4>

# In[131]:


numberOf_ferdowsi_hemasi_words=0
numberOf_hafez_hemasi_words=0
numberOf_iraj_hemasi_words=0
numberOf_parvin_hemasi_words=0
numberOf_mahsati_hemasi_words=0


# <h4 dir="rtl">
# تابع زیر پیرامون شماردن و یافتن درصد کلمات حماسی مربوطه در اشعار شاعر مورد نظرمان ساخته شده است.
#     لازم به ذکر است که اعدادی که در ادامه مشاهده میکنید تا حد خوبی قابل استناد است و همانطور که حدس میزدید درصد حماسی بودن اشعار فردوسی و افسر نسبت به دیگر شاعران بیشتر بود ولیکن اگر داده ی حجیم تری با تعداد کلمات بیشتری کراول میکردیم این اختلاف و اعداد حاصل شده بیشتر میشد ولی بخاطر اینکه بنده سایت دیگری که کلمات فارسی رزمی و حماسی را داشته باشد، پیدا نکردیم بدین خاطر به همین سایت بسنده کردم و نتیجه ی مورد انتطار نیز حاصل گشت.
# </h4>

# In[268]:


def find_numberOf_your_words(poet_mesrae_list , my_words ):
    Unnecessary_words = ["است", "باشد" , "بدو" , "دست" , "کار" , "هوا" , "آمدن" , "پیش" ,   "کردن"]
    num=0
    numberOf_all_word=0
    darsad=0
    for mesrae in poet_mesrae_list:
        numberOf_all_word += len( mesrae.split(" ") )
        for each_hemasi_word in my_words:
            if each_hemasi_word in  mesrae:
                if len(each_hemasi_word)>=3 and each_hemasi_word not in Unnecessary_words:
                    num+=1
    print( "number of hemasi words = %s "%num)
    print("number of all words = %s " %numberOf_all_word)
    
    try:
        darsad=(num/numberOf_all_word)*100
        print("percentage of hemasi words = %s" %darsad)
    except:
        darsad=0
        print("percentage of hemasi words = %s" %darsad)
    return darsad


# In[269]:


darsad_hamasi_bodan_dict={}


# In[270]:


darsad_hamasi_bodan_dict["hafez"]=find_numberOf_your_words(hafez_mesrae_list , just_hemasi_words  )


# In[271]:


darsad_hamasi_bodan_dict["ferdousi"]=find_numberOf_your_words(ferdousi_mesrae_list , just_hemasi_words  )


# In[272]:


darsad_hamasi_bodan_dict["vahshi"]=find_numberOf_your_words(vahshi_mesrae_list , just_hemasi_words  )


# In[273]:


darsad_hamasi_bodan_dict["mahsati"]=find_numberOf_your_words(mahsati_mesrae_list , just_hemasi_words  )


# In[274]:


darsad_hamasi_bodan_dict["jahan"]=find_numberOf_your_words(jahan_mesrae_list , just_hemasi_words  )


# In[275]:


darsad_hamasi_bodan_dict["afsar"]=find_numberOf_your_words(afsar_mesrae_list , just_hemasi_words  )


# In[276]:


darsad_hamasi_bodan_dict["iraj"]=find_numberOf_your_words(iraj_mesrae_list , just_hemasi_words  )


# In[277]:


darsad_hamasi_bodan_dict["parvin"]=find_numberOf_your_words(parvin_mesrae_list , just_hemasi_words  )


# In[278]:


darsad_hamasi_bodan_dict["shahriar"]=find_numberOf_your_words(shahriar_mesrae_list , just_hemasi_words  )


# <h4 dir="rtl">
# حالا با توجه به درصدهایی که در سلول های یالا بیان کردیم، به کمک دیکشنری از پیش ساخته شده میایم و نمودار میله ای را برای درک بهتر تفاوت ها میابیم و همانطور که مشاهده میکنید شاعرانی که سبک عاشقانه دارند همانند حافط، وجود کلمات حماسی در شعرشان کمتر است و همچنین خانم ها اشعار عاطفی بیشتری دارند.
# </h4>

# In[322]:


import pylab as pl
import numpy as np

def draw_barchart_by_dict(darsad , num ):
    X = np.arange(len(darsad))
    pl.bar(X, darsad.values(), align='center', width=0.1)
    pl.xticks(X, darsad.keys())
    ymax = max(darsad.values()) + num
    pl.ylim(0, ymax)
    pl.show()

draw_barchart_by_dict(darsad_hamasi_bodan_dict , 5)


# <h4 dir="rtl">
# حال در ادامه به بررسی متون عاشقانه میپردازیم و روندی مشابه کار بالا را برای متون عاشقانه و احساسی می پیماییم. همچنین برای این کار لیستی از برخی کلمات عاشقانه را آماده کردیم.
# </h4>

# In[280]:


darsad_emotional_bodan_dict={}
emotional_traits_list=["یار","عشق","جان","محبوب","دلبر","جانان","افسانه"
                       ,"دلدار","لیلی","وفا","چشمان" , "لحظه","افلاک"
                       ,"علاقه","مشتاق","نشاط","الهام","امیدوار","خاص",
                       "قلب","لعل","نفس","آغوش","آفاق","عطر" ,"محمل","سحر"
                       ,"دل","هوش","رخ","چشم","چشمان","لبخند","گل","صوفی"
                       ,"زندگی","بوسه","روشن","دلبر","خیال", "عهد","آشنا"
                      "نغمه" , "آفتاب","شمع","پروانه","رقص","مستی","شهاب" 
                      "مرید","سرو","باد","نقاب","قصر","صلح","طره","مهر","آتش",
                      "نسیم","جمال","خاک","جهان","مستی","حاجت","رقیب","شراب" 
                      "هوس","اوقات","ویرانه","طلسم","بوی","خون","خدا","شیرین",
                       "موزون","دیوانه","زلف","موی","پاک","جرعه","چشمه",
                      "سلامت","معجزه","رب","خال","سخن","آشیان","قافله","چشمه","طرب"
                      "انفاس","غم","باده","رقص","ساغر","قلم","خوش","شعر","سوخت","فاتحه",
                      "بهشت","گنج","سال","لبش","شهر","وصل","گنج","رحمت","دستخوش","آینه",
                      "خرقه","نرگس","گوارا","نقاب","قطره","سرزنش","گدای","رمز","بهر", 
                      "نامه","پروانه","جهان","قدر","شرح","فراق","نگران","معرکه","مجلس", 
                      "ساقی","آشمان","مدد","عالم","جمال","کفن","لاله","بهار","برگ","شب" ]


# <h4 dir="rtl">
#     حال همانگونه که انتظار میرفت درصد احساسی بودن اشعار شاعران از قبیل حافط و شهریار و اغلب بانوان که عارفانه عاشقانه است، نسبت به سایز شاعران.
# </h4>

# In[281]:


darsad_emotional_bodan_dict["hafez"]=find_numberOf_your_words(hafez_mesrae_list , emotional_traits_list  )


# In[282]:


darsad_emotional_bodan_dict["ferdousi"]=find_numberOf_your_words(ferdousi_mesrae_list , emotional_traits_list  )


# In[283]:


darsad_emotional_bodan_dict["vahshi"]=find_numberOf_your_words(vahshi_mesrae_list , emotional_traits_list  )


# In[284]:


darsad_emotional_bodan_dict["mahsati"]=find_numberOf_your_words(mahsati_mesrae_list , emotional_traits_list  )


# In[285]:


darsad_emotional_bodan_dict["jahan"]=find_numberOf_your_words(jahan_mesrae_list , emotional_traits_list  )


# In[286]:


darsad_emotional_bodan_dict["afsar"]=find_numberOf_your_words(afsar_mesrae_list , emotional_traits_list  )


# In[287]:


darsad_emotional_bodan_dict["iraj"]=find_numberOf_your_words(iraj_mesrae_list , emotional_traits_list  )


# In[288]:


darsad_emotional_bodan_dict["parvin"]=find_numberOf_your_words(parvin_mesrae_list , emotional_traits_list  )


# In[289]:


darsad_emotional_bodan_dict["shahriar"]=find_numberOf_your_words(shahriar_mesrae_list , emotional_traits_list  )


# In[293]:


draw_barchart_by_dict(darsad_emotional_bodan_dict , 1 )


# <h4 dir="rtl">
#     حال در ادامه با توجه به دسته بندی ای که در ابتدا کرده بودین (شاعران خانم و اقا و معاصران) میخواهیم میانگین تعداد کلمات در ابیات شان را بسنجیم.
# </h4>

# In[364]:


avg_words_in_each_mesrae_dict = {}

def find_avg_words_in_each_mesrae(poet_list):
    numberOf_all_word=0
    for mesrae in poet_list:
        numberOf_all_word += len( mesrae.split(" ") )
    avg =(int(numberOf_all_word /len(poet_list) ))
    print("The average number of words in mesrae = " , end="")
    print (avg) 
    return avg
 


# In[365]:


avg_words_in_each_mesrae_dict["hafez"] = find_avg_words_in_each_mesrae(hafez_mesrae_list )


# In[366]:


avg_words_in_each_mesrae_dict["ferdousi"] = find_avg_words_in_each_mesrae(ferdousi_mesrae_list )


# In[367]:


avg_words_in_each_mesrae_dict["vahshi"] = find_avg_words_in_each_mesrae(vahshi_mesrae_list )


# In[368]:


avg_words_in_each_mesrae_dict["mahsati"] = find_avg_words_in_each_mesrae(mahsati_mesrae_list )


# In[369]:


avg_words_in_each_mesrae_dict["jahan"] = find_avg_words_in_each_mesrae(jahan_mesrae_list )


# In[370]:


avg_words_in_each_mesrae_dict["afsar"] = find_avg_words_in_each_mesrae(afsar_mesrae_list )


# In[371]:


avg_words_in_each_mesrae_dict["iraj"] = find_avg_words_in_each_mesrae( iraj_mesrae_list)


# In[372]:


avg_words_in_each_mesrae_dict["parvin"] = find_avg_words_in_each_mesrae(parvin_mesrae_list )


# In[373]:


avg_words_in_each_mesrae_dict["shahriar"] = find_avg_words_in_each_mesrae(shahriar_mesrae_list )


# <h4 dir="rtl">
#  با توجه به توابع پیشین پی بردیم که سبک شعری شاعران فردوسی و افسر به صورت حماسی است و با توجه به نمودار زیر میتوان دریافت که تعداد کلمات به کاربرده در شعرشان نیز کمتر است نسبت به دیگر شاعران
# </h4>

# In[376]:


draw_barchart_by_dict(avg_words_in_each_mesrae_dict , 3 )


# <h4 dir="rtl">
# حالا در ادامه میخواهیم در اشعاری که داریم ببینیم که شاعر مربوطه چند بار نام خود را در شعر آورده و اصطلاحا تخلص به کار برده است. همچنین این مورد میتواند بیشتر تفاوت اشعار زناان و مردان را نشان دهد زیرا شاعران مرد بیشتر نام خود را در اشعارشان بکار میبرند.
# </h4>

# In[395]:


repetitions_of_the_poets_name={}

def find_repetitions_of_the_poets_name(normalized_dict , name1 , name2 ):
    repetitions=0
    for i in normalized_dict:
        if i.__contains__(name1) or i.__contains__(name2) :
            repetitions+=1
    print(repetitions)
    return repetitions


# In[396]:


repetitions_of_the_poets_name["hafez"] = find_repetitions_of_the_poets_name(mesra_normalized['hafez_ghazal.txt'] , "حافظا" , "حافظ")


# In[397]:


repetitions_of_the_poets_name["ferdousi"] = find_repetitions_of_the_poets_name(mesra_normalized['ferdousi_sohrab.txt'] , "فردوسیا" , "فردوسی")


# In[398]:


repetitions_of_the_poets_name["vahshi"] = find_repetitions_of_the_poets_name(mesra_normalized['vahshi_ghazalv.txt'] , "وحشیا" , "وحشی")


# In[399]:


repetitions_of_the_poets_name["mahsati"] = find_repetitions_of_the_poets_name(mesra_normalized['mahsati_robmah.txt'] , "مهستیا" , "مهستی")


# In[400]:


repetitions_of_the_poets_name["jahan"] = find_repetitions_of_the_poets_name(mesra_normalized['jahan_ghaside.txt'] , "خاتونا" , "خاتون")


# In[401]:


repetitions_of_the_poets_name["afsar"] = find_repetitions_of_the_poets_name(mesra_normalized['afsar_kooroshname.txt'] , "افسرا" , "افسر")


# In[402]:


repetitions_of_the_poets_name["iraj"] = find_repetitions_of_the_poets_name(mesra_normalized['iraj_ghaside.txt'] , "میرزا" , "ایرج")


# In[403]:


repetitions_of_the_poets_name["parvin"] = find_repetitions_of_the_poets_name(mesra_normalized['parvin_ghasidep.txt'] , "پروینا" , "پروین")


# In[404]:


repetitions_of_the_poets_name["shahriar"] = find_repetitions_of_the_poets_name(mesra_normalized['shahriar_gozidegh.txt'] , "حافظا" , "حافظ")


# <h4 dir="rtl">
# از اعداد حاصل شده میتوان دریافت که شاعران خانم خیلی کمتر نام خود را بکار میبردند و همچنین اصولا شاعران قدیمی تر آرایه ی تخلص را بکار میبردند و رفته رفته کمتر شده.
# </h4>

# In[406]:


draw_barchart_by_dict(repetitions_of_the_poets_name , 0 )


# <h4 dir="rtl">
# در ادامه میخواهیم تعداد تکرر کلمه ی زن و مرد را در اشعار مشاهده کنیم و ببینیم که آیا جنسیت شاعران تاثیری در اشعارشان داشته یا خیر.
#     برای این کار هم از stemmer  استفاده میکنیم که موارد اضافه اعم از ضمایر و... را حذف نماید و بتوانیم تحلیل دقیق تری داشته باشیم
#     
#     همچنین در بالاتر ما میانگین وجود یه کلمه را درون متن مان به صورت میانگین نشان دادیم حالا میخواهیم درون هر متن تعدادش را جداگانه نمایش دهیم و به صورت ریشه ای تر نگاه کنیم.
# </h4>

# In[505]:


from hazm import Stemmer
stemmer = Stemmer()

dict_for_my_word={}


# In[506]:


def find_number_of_zan_mard(mesra_normalized , address , my_word1 , my_word2 ):
    counter1=0
    counter2=0
    for mesrae  in mesra_normalized[address]:
        for each_words in mesrae:
                if stemmer.stem(each_words)==my_word1:
                    counter1 +=1
                if stemmer.stem(each_words)== my_word2:
                    counter2 +=1
    print("number of repitation of %s  "%my_word1  ,end="" ) 
    print("is = %s" %counter1)
    print()
    print("number of repitation of %s  "%my_word2  ,end="" ) 
    print("is = %s" %counter2)
    
    return (counter1 , counter2)
        


# In[507]:


dict_for_my_word["hafez"]=find_number_of_zan_mard(mesra_normalized , "hafez_ghazal.txt" , "زن", "مرد")


# In[508]:


dict_for_my_word["ferdousi"]=find_number_of_zan_mard(mesra_normalized , "ferdousi_sohrab.txt" ,"زن", "مرد")


# In[509]:


dict_for_my_word["vahshi"]=find_number_of_zan_mard(mesra_normalized , "vahshi_ghazalv.txt" , "زن", "مرد")


# In[510]:


dict_for_my_word["mahsati"]=find_number_of_zan_mard(mesra_normalized , "mahsati_robmah.txt" , "زن", "مرد")


# In[511]:


dict_for_my_word["jahan"]=find_number_of_zan_mard(mesra_normalized , "jahan_ghaside.txt" , "زن", "مرد")


# In[512]:


dict_for_my_word["afsar"]=find_number_of_zan_mard(mesra_normalized , "afsar_kooroshname.txt" , "زن", "مرد")


# In[513]:


dict_for_my_word["iraj"]=find_number_of_zan_mard(mesra_normalized , "iraj_ghaside.txt" , "زن", "مرد")


# In[514]:


dict_for_my_word["parvin"]=find_number_of_zan_mard(mesra_normalized , "parvin_ghasidep.txt" ,"زن", "مرد")


# In[515]:


dict_for_my_word["shahriar"]=find_number_of_zan_mard(mesra_normalized , "shahriar_gozidegh.txt" ,"زن", "مرد")


# In[516]:


t=(9,2)
n=np.empty(t)
print(n)


# <h4 dir="rtl">حالا با توجه به نمودار رسم شده میتوان دریافت که بیشتر در مورد مرد بودن  و همچنین مردانگی صحبت شده و همچنین با توجه به عقاید قدیمی و محدودیت موجود آن کمتر در مورد زنان صحبت شده.
# </h4>

# In[517]:


import pandas as pd
index_= 0
poet=[]
for key , val in  dict_for_my_word.items():
    a,b = val
    n[index_][0]=a
    n[index_][1]=b
    index_+=1
    poet.append(key)
print(poet)
data=pd.DataFrame(n, columns=["zan" , "mard"] , index=poet )
data.plot.bar()


# <h4 dir="rtl">
# حالا در ادامه نیز اشعاری که مذهبی هستند را و شاعران مربوطه را به دست می اوریم و حالا درون لیست مربوطه میریزیم و قابل مشاهده است.
# 
# </h4>

# In[527]:


mazhabi_words=[]
def crawl_from_mahabi_site(mazhabi_words ):
    address_of_maddahi_site="https://fa.wikishia.net/view/%D8%B1%D9%88%D8%B6%D9%87_%D8%A7%D8%B1%D8%A8%D8%B9%DB%8C%D9%86"
    request_= requests.get(address_of_maddahi_site)
    soup_ = BeautifulSoup(request_.text, "html.parser")
    select_class = soup_.select("p")

    for i in select_class:
        links=i.select('a')
        for j in links:
            if not j.get_text().__contains__("["):
                mazhabi_words.append((j.get_text()))


crawl_from_mahabi_site(mazhabi_words)
print(mazhabi_words)


# <h4 dir="rtl">
# حالا ما باید یک دیکشنری بسازیم و درصد مربوطه را در آن ثبت کنیم.
# </h4>

# In[529]:


darsad_mazhabi_bodan_dict={}


# In[530]:


darsad_mazhabi_bodan_dict["hafez"]=find_numberOf_your_words(hafez_mesrae_list , mazhabi_words )


# In[531]:


darsad_mazhabi_bodan_dict["ferdousi"]=find_numberOf_your_words(ferdousi_mesrae_list , mazhabi_words )


# In[532]:


darsad_mazhabi_bodan_dict["vahshi"]=find_numberOf_your_words(vahshi_mesrae_list , mazhabi_words )


# In[533]:


darsad_mazhabi_bodan_dict["mahsati"]=find_numberOf_your_words(mahsati_mesrae_list , mazhabi_words )


# In[534]:


darsad_mazhabi_bodan_dict["jahan"]=find_numberOf_your_words(jahan_mesrae_list , mazhabi_words )


# In[535]:


darsad_mazhabi_bodan_dict["afsar"]=find_numberOf_your_words(afsar_mesrae_list , mazhabi_words )


# In[536]:


darsad_mazhabi_bodan_dict["iraj"]=find_numberOf_your_words(iraj_mesrae_list , mazhabi_words )


# In[537]:


darsad_mazhabi_bodan_dict["parvin"]=find_numberOf_your_words(parvin_mesrae_list , mazhabi_words )


# In[538]:


darsad_mazhabi_bodan_dict["shahriar"]=find_numberOf_your_words(shahriar_mesrae_list , mazhabi_words )


# <h4 dir="rtl">
#  با توجه به نمودار میتوان  دریافت که بین شاعران، جهان ملک خاتون اشعار مذهبی تری دارد.
# </h4>

# In[540]:


draw_barchart_by_dict(darsad_mazhabi_bodan_dict , 5)


# In[ ]:




